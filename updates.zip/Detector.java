import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import weka.classifiers.Classifier;
import weka.core.Attribute;
import weka.core.Instances;

public class Detector {

//	public static String MODEL_LOCATION = "data_spm/ADABoostM1_30iterations.model";

	public static String TFIDF_LOCATION = "data_spm/tfidf";

	public static String ARFF_LOCATION = "data_spm/train80_infogain_url_tittle_tfidf.arff";

	private TfIdf tfIdf;

	public Instances train;
	
	private String[] attrs;

	public static void main(String[] args) throws Exception {
		Detector d = new Detector();
	}
	
	public Detector() throws Exception {

//		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(MODEL_LOCATION));
//		Classifier cls = (Classifier) ois.readObject();
//		ois.close();

		tfIdf = new TfIdf(TFIDF_LOCATION);	

		train = new Instances(new BufferedReader(new FileReader(ARFF_LOCATION)));		
		train.setClassIndex(train.numAttributes() - 1);
		
		attrs = attributes(train);
	}

	public Map<String, Double> getValues(URL url, String source){
		
		String doc = document(url, source);
		
		Map<String, Double> map = new HashMap<String, Double>();
		
		for(int x=0;x<attrs.length - 1;x++) {
			double v = tfIdf.tfidf(doc, attrs[x]);
			
			map.put(attrs[x], v);
		}
		
		
		return map;
	}
	
	private String document(URL url, String source) {
		Document doc = Jsoup.parse(source);
		
		String text = doc.text().toLowerCase();
		
		text = Feature.addFEATURE_TITTLE(doc.title(), text);
		
		String url_features = url.getFile().replaceAll("[^a-zA-Z0-9.]", "|");
		text = Feature.addFEATURE_URL(url_features, text);
		
		text = text.toLowerCase();
	
		return text;
	}
	
	
	private static String[] attributes(Instances data) {

		Enumeration<Attribute> attrs = data.enumerateAttributes();
		String[] attrNames = new String[data.numAttributes()];

		int i =0;
		while(attrs.hasMoreElements()) {
			Attribute at = attrs.nextElement();
			attrNames[i] = at.name(); 

			i++;
		}

		return attrNames;
	}
	
}
